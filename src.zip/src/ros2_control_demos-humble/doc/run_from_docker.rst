.. note::

   The commands below are given for a local installation of this repository and its dependencies as well as for running them from a docker container. For more information on the docker usage see :ref:`doc/ros2_control_demos/doc/index:using docker`.
