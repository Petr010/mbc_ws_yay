#ifndef DEFINES_HPP
#define DEFINES_HPP

namespace ldlidar
{

}

#endif // DEFINES_HPP
